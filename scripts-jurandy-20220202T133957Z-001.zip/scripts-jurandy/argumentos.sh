#!/usr/bin/bash

# env |sort | grep -v LS_COLORS |batcat

echo "O que é isso 1?" $#
echo "O que é isso 2?" $?
echo "O que é isso 3?" $*