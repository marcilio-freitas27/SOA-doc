#!/usr/bin/bash
ANO=$(date +%Y)
mkdir -p ${ANO}/{01..12}/{01..31}
rmdir ${ANO}/{04,07,09,11}/31
rmdir ${ANO}/02/{29,30,31}

declare -A nome_mes

nome_mes[01]=Janeiro
nome_mes[02]=Fevereiro
nome_mes[03]=Marco
nome_mes[04]=Abril
nome_mes[05]=Maio
nome_mes[06]=Junho
nome_mes[07]=Julho
nome_mes[08]=Agosto
nome_mes[09]=Setembro
nome_mes[10]=Outubro
nome_mes[11]=Novembro
nome_mes[12]=Dezembro

for i in {01..12}
    do
        echo "# ${nome_mes[$i]}" >> ${ANO}/${i}/index.md;
    done

    