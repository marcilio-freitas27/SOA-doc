# Semana 08

 1. meses com 30 dias   
 * abril, junho, setembro e novembro.

 - `mkdir 2021/{01..12}/{01..31}`
 - `rmdir 2021/{04,07,09,11}/31`
 - `tree`
 - `find `
 - `find |grep 31`
 - `find |grep 31 |sort `
 - `rmdir 2021/02/{29, 30, 31}`
 - `rmdir 2021/02/{29,30,31}`
 - `find |grep 31 |sort `

 ## shebang 